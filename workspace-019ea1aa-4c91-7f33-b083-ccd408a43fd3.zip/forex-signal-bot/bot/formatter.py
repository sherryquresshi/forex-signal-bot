"""Pretty Telegram message formatting (Markdown)."""
from __future__ import annotations


def format_analysis(pair: str, interval: str, bias: dict) -> str:
    emoji = {"BULLISH": "🟢⬆️", "BEARISH": "🔴⬇️", "NEUTRAL": "⚪️➖"}[bias["bias"]]
    lines = [
        f"*{pair}* · `{interval}` · live analysis",
        f"Price: `{bias['price']:.5f}`  ·  ATR: `{bias['atr']:.5f}`",
        "",
        f"*Bias: {emoji} {bias['bias']}*  (score `{bias['score']:+d}`)",
        "",
        "*Indicator votes:*",
    ]
    for name, v, reason in bias["votes"]:
        mark = "🟢" if v > 0 else ("🔴" if v < 0 else "⚪️")
        lines.append(f"{mark} *{name}*: {reason}")
    lines += ["", "_Educational only. Not financial advice._"]
    return "\n".join(lines)


def format_signal(sig: dict, plan: dict, session: tuple, news: dict) -> str:
    """The full high-conviction signal message."""
    if "error" in sig:
        return f"❌ {sig['error']}"

    pred = sig["ml"]
    hb = sig["higher_bias"]
    rec = sig["recommendation"]
    conv = sig["conviction"]
    arrow = "⬆️ LONG" if pred["direction"] == "UP" else "⬇️ SHORT"

    bar = "█" * int(conv / 10) + "░" * (10 - int(conv / 10))

    lines = [
        f"━━━━━━━━━━━━━━━━━━━━",
        f"📊 *{sig['pair']}* · `{sig['interval']}` signal",
        f"━━━━━━━━━━━━━━━━━━━━",
        "",
        f"*{rec}*",
        "",
        f"Direction: *{arrow}*",
        f"Conviction: `{bar}` *{conv}%*",
        "",
        f"*Entry zone:* `{plan['entry']:.5f}`",
        f"🛑 Stop loss: `{plan['sl']:.5f}` (`{plan['sl_pips']:.1f}` pips)",
        f"🎯 TP1: `{plan['tp1']:.5f}` (`{plan['tp1_pips']:.1f}` pips)",
        f"🎯 TP2: `{plan['tp2']:.5f}` (`{plan['tp2_pips']:.1f}` pips)",
        f"R:R = `1:{plan['rr']:.2f}`  ·  Suggested size: `{plan['lots']}` lots @ 1% risk",
        "",
        f"*Why:*",
        f"• ML on {sig['interval']}: {pred['direction']} ({pred['p_up']*100:.1f}% up)",
        f"• Higher TF ({sig['higher_tf']}): {hb['bias']} (score {hb['score']:+d})",
        f"• Agreement: {'✅ YES' if sig['agreement'] else '❌ NO'}",
        "",
        f"*Filters:*",
        f"• Session: {session[0]} — {session[1]}",
        f"• News: {news['msg']}",
        "",
        f"*Model edge (backtest):* acc `{pred['backtest']['accuracy']*100:.1f}%`  ·  PF `{pred['backtest']['profit_factor']:.2f}`",
        "",
        "_📝 Paper-tracked. Check `/stats` later to see real win rate._",
        "_Educational only. Not financial advice._",
    ]
    return "\n".join(lines)


def format_backtest(pair: str, interval: str, horizon: int, bt: dict) -> str:
    return "\n".join([
        f"*{pair}* · `{interval}` · walk-forward backtest",
        f"Horizon: `{horizon}` candle(s)",
        "",
        f"Samples: `{bt['samples']}`",
        f"Accuracy: `{bt['accuracy']*100:.2f}%`",
        f"Precision (long): `{bt['precision_long']*100:.2f}%`",
        f"Recall (long): `{bt['recall_long']*100:.2f}%`",
        f"Profit factor: `{bt['profit_factor']:.2f}`",
        f"Wins: `{bt['wins']}` · Losses: `{bt['losses']}`",
        f"Avg win: `{bt['avg_win_pips']:.2f}` pips",
        f"Avg loss: `{bt['avg_loss_pips']:.2f}` pips",
        "",
        "_A profit factor of 1.0 = breakeven. <1.0 loses money._",
    ])


def format_stats(stats: dict, pair: str | None = None) -> str:
    head = f"*Live paper-trading stats*" + (f" — {pair}" if pair else "")
    if stats["total"] == 0:
        return head + "\n\nNo closed signals yet. Check back after a few signals have played out."
    return "\n".join([
        head, "",
        f"Closed signals: `{stats['total']}`",
        f"Wins: `{stats['wins']}`  ·  Losses: `{stats['losses']}`",
        f"Win rate: *{stats['win_rate']:.1f}%*",
        f"Total pips: `{stats['total_pips']:+.1f}`",
        f"Avg pips/trade: `{stats['avg_pips']:+.2f}`",
        "",
        "_This is real performance, not a backtest._",
    ])
