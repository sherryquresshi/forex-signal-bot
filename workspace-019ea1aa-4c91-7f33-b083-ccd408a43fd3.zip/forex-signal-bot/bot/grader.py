"""Background job: periodically check open paper-signals and grade them
once price hits SL, TP1, TP2, or the horizon expires.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

from . import data_fetcher, signal_log

log = logging.getLogger("grader")


async def grade_loop(interval_sec: int = 300):
    while True:
        try:
            grade_once()
        except Exception as e:
            log.warning(f"grader error: {e}")
        await asyncio.sleep(interval_sec)


def grade_once():
    open_sigs = signal_log.get_open_signals()
    if not open_sigs:
        return
    log.info(f"Grading {len(open_sigs)} open signals…")
    # cache per pair/interval
    cache: dict[tuple[str, str], object] = {}

    for s in open_sigs:
        key = (s["pair"], s["interval"])
        if key not in cache:
            cache[key] = data_fetcher.get_ohlc(s["pair"], s["interval"])
        df = cache[key]
        if df is None or df.empty:
            continue

        opened_at = datetime.fromisoformat(s["ts"])
        future = df[df.index > opened_at]
        if future.empty:
            continue

        sign = +1 if s["direction"] == "UP" else -1
        sl, tp2 = s["sl"], s["tp2"]
        psize = 0.01 if "JPY" in s["pair"] else 0.0001

        for ts, row in future.iterrows():
            hi, lo = row["high"], row["low"]
            # Stop hit?
            if (sign == +1 and lo <= sl) or (sign == -1 and hi >= sl):
                pips = (sl - s["entry"]) / psize * sign
                signal_log.close_signal(s["id"], sl, "LOSS", pips)
                break
            # TP2 hit?
            if (sign == +1 and hi >= tp2) or (sign == -1 and lo <= tp2):
                pips = (tp2 - s["entry"]) / psize * sign
                signal_log.close_signal(s["id"], tp2, "WIN", pips)
                break
        else:
            # Time stop: if signal older than horizon * candle minutes * 3
            minutes_per_candle = {"1m": 1, "5m": 5, "15m": 15, "30m": 30,
                                  "1h": 60, "4h": 240, "1d": 1440}.get(s["interval"], 15)
            age_min = (datetime.now(timezone.utc) - opened_at).total_seconds() / 60
            if age_min > s["horizon"] * minutes_per_candle * 3:
                last_close = future.iloc[-1]["close"]
                pips = (last_close - s["entry"]) / psize * sign
                result = "WIN" if pips > 0 else "LOSS"
                signal_log.close_signal(s["id"], last_close, result, pips)
