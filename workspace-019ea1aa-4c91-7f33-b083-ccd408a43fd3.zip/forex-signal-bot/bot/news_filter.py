"""Economic-news avoidance.

Most retail accounts blow up around high-impact news (NFP, CPI, FOMC, ECB).
We pull a free calendar feed and warn the user if a high-impact event for
the pair's currencies is within ±30 minutes.

Source: Financial Modeling Prep (free tier, no key for basic) +
nfs.faireconomy.media as a backup XML feed.
"""
from __future__ import annotations

import re
import time
from datetime import datetime, timedelta, timezone
from typing import Optional

import requests

CACHE: dict[str, tuple[float, list[dict]]] = {}
CACHE_TTL = 60 * 30  # 30 min

FF_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"


def _fetch_calendar() -> list[dict]:
    now = time.time()
    cached = CACHE.get("cal")
    if cached and now - cached[0] < CACHE_TTL:
        return cached[1]
    try:
        r = requests.get(FF_URL, timeout=10)
        data = r.json()
        # Normalize
        events = []
        for e in data:
            try:
                dt = datetime.fromisoformat(e["date"].replace("Z", "+00:00"))
                events.append({
                    "time": dt,
                    "country": e.get("country", "").upper(),
                    "title": e.get("title", ""),
                    "impact": e.get("impact", "").lower(),  # "high"/"medium"/"low"
                })
            except Exception:
                continue
        CACHE["cal"] = (now, events)
        return events
    except Exception as ex:
        print(f"[news] fetch error: {ex}")
        return cached[1] if cached else []


# Map currency to ForexFactory country code
CCY_TO_COUNTRY = {
    "USD": "USD", "EUR": "EUR", "GBP": "GBP", "JPY": "JPY",
    "AUD": "AUD", "NZD": "NZD", "CAD": "CAD", "CHF": "CHF",
}


def pair_currencies(pair: str) -> tuple[str, str]:
    pair = pair.upper()
    if len(pair) >= 6:
        return pair[:3], pair[3:6]
    return ("", "")


def check_news(pair: str, window_min: int = 30) -> dict:
    """Return {'safe': bool, 'events': [...], 'msg': str}."""
    base, quote = pair_currencies(pair)
    ccys = {CCY_TO_COUNTRY.get(base), CCY_TO_COUNTRY.get(quote)} - {None}
    if "XAU" in pair or "GOLD" in pair.upper():
        ccys.add("USD")  # gold is USD-driven

    cal = _fetch_calendar()
    now = datetime.now(timezone.utc)
    soon = []
    for e in cal:
        if e["impact"] != "high":
            continue
        if e["country"] not in ccys:
            continue
        delta_min = (e["time"] - now).total_seconds() / 60
        if -window_min <= delta_min <= window_min:
            soon.append({
                "title": e["title"], "country": e["country"],
                "in_min": int(delta_min),
            })
    if soon:
        names = ", ".join(f"{e['country']} {e['title']} ({e['in_min']:+d}m)" for e in soon[:3])
        return {"safe": False, "events": soon,
                "msg": f"⚠️ High-impact news within ±{window_min}m: {names}"}
    return {"safe": True, "events": [], "msg": "✅ No high-impact news nearby"}
