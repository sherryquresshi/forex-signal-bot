"""Multi-timeframe agreement — a high-conviction signal requires the
trade timeframe AND a higher timeframe to agree.

E.g. trading 15m signals only when 1h also points the same direction
historically improves win rate noticeably.
"""
from __future__ import annotations

from . import data_fetcher, indicators, ml_model

HIGHER_TF = {
    "1m": "15m", "5m": "30m", "15m": "1h",
    "30m": "4h", "1h": "4h", "4h": "1d", "1d": "1d",
}


def multi_tf_signal(pair: str, interval: str, horizon: int = 4) -> dict:
    """Combine trade-TF ML prediction with higher-TF trend bias."""
    df_lo = data_fetcher.get_ohlc(pair, interval)
    if df_lo is None or len(df_lo) < 600:
        return {"error": f"No data for {pair} {interval}"}

    pred = ml_model.predict_next(df_lo, pair, interval, horizon)

    higher = HIGHER_TF.get(interval, "1h")
    df_hi = data_fetcher.get_ohlc(pair, higher)
    if df_hi is None or df_hi.empty:
        higher_bias = {"bias": "NEUTRAL", "score": 0}
    else:
        higher_bias = indicators.rule_based_bias(df_hi)

    ml_dir = pred["direction"]
    htf_dir = higher_bias["bias"]
    agree = (ml_dir == "UP" and htf_dir == "BULLISH") or \
            (ml_dir == "DOWN" and htf_dir == "BEARISH")

    # Conviction score (0–100)
    conviction = pred["confidence"] * 50  # base
    if agree:
        conviction += 30
    elif htf_dir == "NEUTRAL":
        conviction += 10
    # Strong indicator score on higher TF adds more
    conviction += min(abs(higher_bias.get("score", 0)) * 5, 20)
    conviction = round(min(conviction, 100), 1)

    return {
        "pair": pair, "interval": interval, "horizon": horizon,
        "higher_tf": higher,
        "ml": pred,
        "higher_bias": higher_bias,
        "agreement": agree,
        "conviction": conviction,
        "recommendation": _recommend(agree, pred, conviction),
    }


def _recommend(agree: bool, pred: dict, conviction: float) -> str:
    bt = pred.get("backtest", {})
    pf = bt.get("profit_factor", 0)
    acc = bt.get("accuracy", 0)
    if not agree:
        return "⛔ SKIP — timeframes disagree"
    if conviction < 60:
        return "⚠️ WAIT — conviction too low"
    if pf < 1.1 or acc < 0.53:
        return "⛔ SKIP — model has no proven edge for this pair"
    return f"✅ TAKE — high-conviction {pred['direction']}"
