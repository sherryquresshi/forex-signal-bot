"""Identify the forex pair + timeframe from a chart screenshot using vision AI.

We deliberately DO NOT try to OCR candles — that's lossy garbage.
Instead, we identify what the user is looking at, then fetch the *real* data.
"""
from __future__ import annotations

import base64
import json
import os
from typing import Optional

try:
    from openai import OpenAI
    HAVE_OPENAI = True
except Exception:
    HAVE_OPENAI = False


SYSTEM = """You analyze trading chart screenshots. Return STRICT JSON:
{"pair": "EURUSD", "timeframe": "15m", "confidence": 0.0-1.0, "notes": "short string"}

Rules:
- pair: 6-letter uppercase (EURUSD, GBPJPY, XAUUSD, etc.). If not forex/gold, return "UNKNOWN".
- timeframe: one of 1m,5m,15m,30m,1h,4h,1d. Best guess from axis labels / candle density.
- confidence: how sure you are.
- notes: e.g. "MT4 screenshot, EURUSD M15 clearly labeled".
Return ONLY the JSON, nothing else."""


def identify_chart(image_bytes: bytes) -> Optional[dict]:
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key or not HAVE_OPENAI:
        return None
    client = OpenAI(api_key=api_key)
    b64 = base64.b64encode(image_bytes).decode()
    try:
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": [
                    {"type": "text", "text": "Identify this chart."},
                    {"type": "image_url",
                     "image_url": {"url": f"data:image/png;base64,{b64}"}},
                ]},
            ],
            max_tokens=200,
            temperature=0,
        )
        txt = resp.choices[0].message.content.strip()
        # strip ``` fences if any
        if txt.startswith("```"):
            txt = txt.strip("`")
            if txt.lower().startswith("json"):
                txt = txt[4:]
        data = json.loads(txt)
        return data
    except Exception as e:
        print(f"[vision] error: {e}")
        return None
