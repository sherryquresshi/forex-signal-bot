# Forex Signal Telegram Bot 🤖📊

A **free**, **honest** Telegram bot that analyzes forex pairs using:
- ✅ **Live data** from Yahoo Finance & Twelve Data (free tier)
- ✅ **Real technical indicators** (RSI, MACD, Bollinger Bands, EMA, ATR)
- ✅ **Screenshot analysis** (vision AI identifies the asset, then pulls real data)
- ✅ **ML prediction** (XGBoost classifier with walk-forward backtest)
- ✅ **Backtest report** so you see the *actual* historical accuracy — no fake "98% win rate" claims

---

## ⚠️ Honest Disclaimer (Read This)

- This bot is for **education and research only**. Not financial advice.
- Realistic ML accuracy on short-term forex prediction is **~50–58%**. Anyone claiming higher is lying or overfitting.
- Backtest results ≠ live results. Markets change. Slippage and spread eat edges.
- **Never risk money you can't afford to lose.**

---

## Commands

| Command | What it does |
|---|---|
| `/start` | Welcome + help |
| `/signal EURUSD 15m` | ⭐ Full high-conviction signal: multi-TF + news + risk plan |
| `/analyze EURUSD 15m` | Live indicator analysis |
| `/backtest EURUSD 15m 4` | Walk-forward backtest |
| `/stats` | Live paper-trade win rate |
| `/sessions` | Which forex markets are open now |
| `/news EURUSD` | High-impact news check |
| `/pairs` | List supported pairs |
| (Send a photo) | Bot identifies the pair from your screenshot and runs `/signal` |

---

## Project Structure

```
forex-signal-bot/
├── bot/
│   ├── main.py              # Telegram bot entry point
│   ├── data_fetcher.py      # Pulls live forex OHLC data
│   ├── indicators.py        # RSI, MACD, BB, EMA, ATR
│   ├── ml_model.py          # XGBoost training + prediction + backtest
│   ├── screenshot.py        # Vision: identify pair from chart screenshot
│   └── formatter.py         # Pretty Telegram messages
├── models/                  # Saved trained models per pair
├── data/                    # Cached OHLC data
├── requirements.txt
├── .env.example
├── Procfile                 # For Render/Railway deploy
└── README.md
```

---

## 🍼 Non-developer? Read this instead → [INSTALL_GUIDE.md](INSTALL_GUIDE.md)

That guide walks you through everything in plain English, no jargon, with screenshots-style steps.

---

## Setup (for developers, 5 minutes)

### 1. Get a free Telegram bot token
- Open Telegram → search **@BotFather** → `/newbot` → follow prompts → copy the token.

### 2. (Optional) Get a free Twelve Data API key
- Sign up at https://twelvedata.com (free tier = 800 requests/day) — used as fallback to Yahoo.

### 3. (Optional, for screenshot feature) OpenAI API key
- The screenshot feature uses GPT-4o-mini vision (~$0.0001/image). If you skip this, the bot still works via `/analyze` commands.

### 4. Configure
```bash
cp .env.example .env
# edit .env and paste your tokens
```

### 5. Install & run locally
```bash
pip install -r requirements.txt
python -m bot.main
```

### 6. Deploy free on Render
- Push this folder to a GitHub repo
- Go to https://render.com → New → Background Worker → connect repo
- Add the env vars from `.env`
- Start command: `python -m bot.main`
- Free tier sleeps after inactivity; for 24/7 use UptimeRobot to ping, or upgrade ($7/mo)

---

## How the ML Model Works (so you can trust it)

1. Pulls ~2 years of historical OHLC data for the pair/timeframe
2. Builds features: returns, RSI, MACD histogram, BB position, EMA distances, ATR, volume z-score, hour-of-day, day-of-week
3. Target = `1` if price `N` candles ahead is higher than now, else `0`
4. Trains an XGBoost classifier with **walk-forward cross-validation** (no lookahead bias)
5. Reports: accuracy, precision, recall, profit factor on a paper-trade simulation with realistic spread (1 pip)

Run `/backtest EURUSD 15m` and you'll see the **honest** numbers.
