"""Fetch live forex OHLC data.

Primary source: Yahoo Finance (free, no key, ~1-min delay).
Fallback:       Twelve Data (free 800 req/day with API key).
"""
from __future__ import annotations

import os
import time
from datetime import datetime, timedelta
from typing import Optional

import pandas as pd
import requests
import yfinance as yf

# Map of common pair symbols → Yahoo ticker
YAHOO_MAP = {
    "EURUSD": "EURUSD=X", "GBPUSD": "GBPUSD=X", "USDJPY": "USDJPY=X",
    "AUDUSD": "AUDUSD=X", "USDCAD": "USDCAD=X", "USDCHF": "USDCHF=X",
    "NZDUSD": "NZDUSD=X", "EURGBP": "EURGBP=X", "EURJPY": "EURJPY=X",
    "GBPJPY": "GBPJPY=X", "XAUUSD": "GC=F",  # gold futures
}

# Yahoo accepted intervals
YAHOO_INTERVALS = {
    "1m": ("1m", "7d"),    "2m": ("2m", "60d"),
    "5m": ("5m", "60d"),   "15m": ("15m", "60d"),
    "30m": ("30m", "60d"), "1h": ("60m", "730d"),
    "4h": ("1h", "730d"),  # 4h built by resampling 1h
    "1d": ("1d", "max"),
}

TWELVEDATA_INTERVALS = {
    "1m": "1min", "5m": "5min", "15m": "15min", "30m": "30min",
    "1h": "1h", "4h": "4h", "1d": "1day",
}


def normalize_pair(pair: str) -> str:
    """EURUSD, EUR/USD, eurusd → EURUSD"""
    return pair.upper().replace("/", "").replace("-", "").strip()


def fetch_yahoo(pair: str, interval: str) -> Optional[pd.DataFrame]:
    pair = normalize_pair(pair)
    if pair not in YAHOO_MAP:
        return None
    ticker = YAHOO_MAP[pair]

    if interval == "4h":
        yi, period = "60m", "730d"
    else:
        yi, period = YAHOO_INTERVALS.get(interval, ("15m", "60d"))

    try:
        df = yf.download(
            ticker, period=period, interval=yi,
            progress=False, auto_adjust=False, threads=False,
        )
        if df is None or df.empty:
            return None
        # flatten possible multiindex columns
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [c[0] for c in df.columns]
        df = df.rename(columns=str.lower)[["open", "high", "low", "close", "volume"]]
        if interval == "4h":
            df = df.resample("4H").agg({
                "open": "first", "high": "max", "low": "min",
                "close": "last", "volume": "sum",
            }).dropna()
        return df
    except Exception as e:
        print(f"[yahoo] error: {e}")
        return None


def fetch_twelvedata(pair: str, interval: str, outputsize: int = 5000) -> Optional[pd.DataFrame]:
    api_key = os.getenv("TWELVEDATA_API_KEY", "")
    if not api_key:
        return None
    pair = normalize_pair(pair)
    if len(pair) != 6:
        return None
    symbol = f"{pair[:3]}/{pair[3:]}"
    tdi = TWELVEDATA_INTERVALS.get(interval, "15min")
    url = "https://api.twelvedata.com/time_series"
    try:
        r = requests.get(url, params={
            "symbol": symbol, "interval": tdi,
            "outputsize": outputsize, "apikey": api_key,
        }, timeout=15)
        data = r.json()
        if "values" not in data:
            print(f"[twelvedata] {data}")
            return None
        df = pd.DataFrame(data["values"])
        df["datetime"] = pd.to_datetime(df["datetime"])
        df = df.set_index("datetime").sort_index()
        for c in ["open", "high", "low", "close"]:
            df[c] = df[c].astype(float)
        df["volume"] = 0.0  # FX usually has no volume
        return df[["open", "high", "low", "close", "volume"]]
    except Exception as e:
        print(f"[twelvedata] error: {e}")
        return None


def get_ohlc(pair: str, interval: str = "15m") -> Optional[pd.DataFrame]:
    """Try Yahoo first, fall back to Twelve Data."""
    df = fetch_yahoo(pair, interval)
    if df is not None and len(df) > 50:
        return df
    df = fetch_twelvedata(pair, interval)
    return df


def supported_pairs() -> list[str]:
    return sorted(YAHOO_MAP.keys())


if __name__ == "__main__":
    # Quick local test
    df = get_ohlc("EURUSD", "15m")
    print(df.tail() if df is not None else "no data")
