"""XGBoost-based directional classifier with walk-forward backtest.

We train *per pair + timeframe + horizon* and cache the model on disk.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score

try:
    from xgboost import XGBClassifier
    HAVE_XGB = True
except Exception:
    HAVE_XGB = False
    from sklearn.ensemble import GradientBoostingClassifier

from .indicators import add_all

MODELS_DIR = Path(__file__).resolve().parent.parent / "models"
MODELS_DIR.mkdir(exist_ok=True)

FEATURE_COLS = [
    "rsi14", "macd", "macd_sig", "macd_hist",
    "bb_pos", "ema20", "ema50", "ema200",
    "atr14", "ret_1", "ret_3", "ret_5",
    "hour", "dow",
]


def build_features(df: pd.DataFrame, horizon: int) -> tuple[pd.DataFrame, pd.Series]:
    d = add_all(df).copy()
    d["hour"] = d.index.hour
    d["dow"] = d.index.dayofweek
    # Target: 1 if close `horizon` candles ahead > current close
    d["future"] = d["close"].shift(-horizon)
    d["target"] = (d["future"] > d["close"]).astype(int)
    d = d.dropna()
    X = d[FEATURE_COLS]
    y = d["target"]
    return X, y


def model_path(pair: str, interval: str, horizon: int) -> Path:
    return MODELS_DIR / f"{pair}_{interval}_{horizon}.joblib"


def _make_model():
    if HAVE_XGB:
        return XGBClassifier(
            n_estimators=300, max_depth=4, learning_rate=0.05,
            subsample=0.85, colsample_bytree=0.85,
            eval_metric="logloss",
            n_jobs=1, random_state=42,
        )
    return GradientBoostingClassifier(
        n_estimators=200, max_depth=3, learning_rate=0.05, random_state=42,
    )


@dataclass
class BacktestResult:
    samples: int
    accuracy: float
    precision_long: float
    recall_long: float
    profit_factor: float
    wins: int
    losses: int
    avg_win_pips: float
    avg_loss_pips: float


def walk_forward_backtest(df: pd.DataFrame, horizon: int, n_splits: int = 5,
                          spread_pips: float = 1.0) -> tuple[BacktestResult, object]:
    """Trains on expanding windows, evaluates out-of-sample.
    Returns metrics + a model trained on the full dataset for live use.
    """
    X, y = build_features(df, horizon)
    if len(X) < 500:
        raise ValueError(f"Not enough data ({len(X)} rows) — need at least 500.")

    fold_size = len(X) // (n_splits + 1)
    preds_all, true_all = [], []
    pips_log: list[float] = []

    # 1 pip = 0.0001 for most majors, 0.01 for JPY pairs (rough)
    pip_size = 0.0001

    for i in range(n_splits):
        train_end = fold_size * (i + 1)
        test_end = fold_size * (i + 2)
        X_tr, y_tr = X.iloc[:train_end], y.iloc[:train_end]
        X_te, y_te = X.iloc[train_end:test_end], y.iloc[train_end:test_end]
        if len(X_te) == 0:
            continue
        m = _make_model()
        m.fit(X_tr, y_tr)
        p = m.predict(X_te)
        preds_all.extend(p.tolist())
        true_all.extend(y_te.tolist())

        # paper P&L: enter on signal, exit `horizon` later, subtract spread
        close = df["close"].reindex(X_te.index)
        future = df["close"].shift(-horizon).reindex(X_te.index)
        for pred, c, f in zip(p, close.values, future.values):
            if np.isnan(c) or np.isnan(f):
                continue
            direction = 1 if pred == 1 else -1
            pnl = direction * (f - c) - spread_pips * pip_size
            pips_log.append(pnl / pip_size)

    pips_arr = np.array(pips_log)
    wins = pips_arr[pips_arr > 0]
    losses = pips_arr[pips_arr <= 0]
    pf = (wins.sum() / abs(losses.sum())) if losses.sum() != 0 else float("inf")

    res = BacktestResult(
        samples=len(preds_all),
        accuracy=accuracy_score(true_all, preds_all),
        precision_long=precision_score(true_all, preds_all, zero_division=0),
        recall_long=recall_score(true_all, preds_all, zero_division=0),
        profit_factor=float(pf),
        wins=int(len(wins)),
        losses=int(len(losses)),
        avg_win_pips=float(wins.mean()) if len(wins) else 0.0,
        avg_loss_pips=float(losses.mean()) if len(losses) else 0.0,
    )

    # Final model trained on everything
    final = _make_model()
    final.fit(X, y)
    return res, final


def train_and_save(df: pd.DataFrame, pair: str, interval: str, horizon: int) -> BacktestResult:
    res, model = walk_forward_backtest(df, horizon)
    joblib.dump({"model": model, "features": FEATURE_COLS, "horizon": horizon,
                 "backtest": res.__dict__},
                model_path(pair, interval, horizon))
    return res


def load_model(pair: str, interval: str, horizon: int):
    p = model_path(pair, interval, horizon)
    if not p.exists():
        return None
    return joblib.load(p)


def predict_next(df: pd.DataFrame, pair: str, interval: str, horizon: int) -> dict:
    bundle = load_model(pair, interval, horizon)
    trained_now = False
    if bundle is None:
        res = train_and_save(df, pair, interval, horizon)
        bundle = load_model(pair, interval, horizon)
        trained_now = True

    X, _ = build_features(df, horizon)
    if X.empty:
        return {"error": "Not enough data"}
    last = X.iloc[[-1]]
    model = bundle["model"]
    proba = model.predict_proba(last)[0]
    p_up = float(proba[1])
    return {
        "p_up": p_up,
        "p_down": 1 - p_up,
        "direction": "UP" if p_up >= 0.5 else "DOWN",
        "confidence": abs(p_up - 0.5) * 2,
        "backtest": bundle["backtest"],
        "trained_now": trained_now,
    }
