# 🍼 Super-Simple Install Guide (No Coding Background Needed)

Hi! I'll walk you through this like I'm sitting next to you.

You'll need about **30 minutes** and these things:
- A computer (Windows / Mac / Linux — any works)
- An internet connection
- A Telegram account on your phone
- An email address

**Total cost: $0.** Everything we use has a free tier.

---

## 📋 Big picture (so you know what we're doing)

We're going to:

1. 🤖 Create a Telegram bot (5 min)
2. 📦 Put the bot's code on GitHub (5 min)
3. ☁️ Run it on a free cloud server called Render so it works 24/7 (10 min)
4. 💬 Talk to your bot in Telegram (instant)

That's it. Let's go.

---

## STEP 1 — Create your Telegram bot (5 minutes)

A "bot" on Telegram is just a special account. You make one by talking to a bot called **BotFather**.

### 1.1
Open Telegram on your phone. In the search bar at the top, type:

```
BotFather
```

Tap the one with the **blue checkmark** ✓ (that's the official one — important!).

### 1.2
Press the **START** button at the bottom.

### 1.3
Type and send this:
```
/newbot
```

### 1.4
BotFather asks for a **name**. This is what people see. Type anything you like, like:
```
My Forex Signals
```

### 1.5
BotFather asks for a **username**. It must end with `bot`. Try:
```
my_forex_signals_2026_bot
```
(if taken, try another — add numbers)

### 1.6
🎉 BotFather sends you a message with a long secret code that looks like:
```
7891234567:AAEhBkH2zXq9YpVwLm-...
```

**This is your TELEGRAM TOKEN.** It's like a password. **Copy it and save it in a note on your phone**. Don't show it to anyone. We'll use it in Step 3.

✅ **Step 1 done!**

---

## STEP 2 — Put the bot code on GitHub (5 minutes)

GitHub is a free website that stores code. Render (the cloud server) will read the code from here.

### 2.1 — Make a free GitHub account

Open in a browser: https://github.com/signup

Sign up with your email. Pick a username, password, verify your email. Skip the "personalization" questions if you want.

### 2.2 — Create a new "repository" (just a folder online)

After logging in:

- Click the green **New** button (or the **+** at the top-right → "New repository")
- **Repository name:** type `forex-signal-bot`
- **Public** is fine (free option)
- ✅ Check the box "**Add a README file**"
- Click the green **Create repository** button

### 2.3 — Upload the bot files

You should now see a page showing your new (almost-empty) repo.

- Click **Add file** → **Upload files**
- On your computer, open the `forex-signal-bot` folder I built for you
- **Select ALL the files and folders inside** (Ctrl+A on Windows, Cmd+A on Mac)
- Drag them onto the GitHub page
- Wait for upload to finish (the bar at the bottom)
- Scroll down → click the green **Commit changes** button

✅ **Step 2 done!** Your code is now online.

---

## STEP 3 — Run the bot 24/7 on Render (10 minutes)

Render is a free cloud server. It will run your bot all day, every day.

### 3.1 — Make a free Render account

Open: https://render.com

Click **Get Started** → choose **Sign up with GitHub** (this is easiest, it links them automatically). Approve the permission.

### 3.2 — Create a new "Background Worker"

On the Render dashboard:

- Click the purple **+ New** button at the top
- Choose **Background Worker**
- Render asks "Connect a repository" → click **Connect** next to `forex-signal-bot`
  (if you don't see it, click "Configure account" and give Render access to that repo)

### 3.3 — Fill in the settings

A form appears. Fill it in **exactly** like this:

| Field | What to type |
|---|---|
| **Name** | `forex-signal-bot` |
| **Region** | Pick the one closest to you |
| **Branch** | `main` |
| **Runtime** | `Python 3` |
| **Build Command** | `pip install -r requirements.txt` |
| **Start Command** | `python -m bot.main` |
| **Instance Type** | **Free** |

### 3.4 — Add your secret keys (Environment Variables)

Scroll down to **Environment Variables**. Click **Add Environment Variable** and add this:

| Key | Value |
|---|---|
| `TELEGRAM_BOT_TOKEN` | (paste the long code from BotFather you saved) |

**Optional** (you can add these later or skip):
| Key | Value | What it does |
|---|---|---|
| `TWELVEDATA_API_KEY` | (free from https://twelvedata.com/register) | Backup data source if Yahoo is slow |
| `OPENAI_API_KEY` | (from https://platform.openai.com — needs $5 credit) | Enables screenshot feature |

### 3.5 — Click the big purple button

Scroll down and click **Create Background Worker**.

Render now downloads your code, installs everything, and starts the bot. This takes about **3–5 minutes**. You'll see scrolling text — that's normal.

When you see this line, you're done:
```
Bot starting (polling)…
```

✅ **Step 3 done! Your bot is now ALIVE on the internet 24/7.**

---

## STEP 4 — Talk to your bot 💬

### 4.1
Open Telegram. In the search bar, type your bot's **username** (the one ending in `bot` from Step 1.5).

### 4.2
Tap it → press **START**.

### 4.3
Try these commands one by one:

```
/start
```
↑ Shows the help menu.

```
/sessions
```
↑ Tells you which forex markets are open right now.

```
/analyze EURUSD 15m
```
↑ Live analysis with all indicators.

```
/signal EURUSD 15m
```
↑ ⭐ The main one. Full high-conviction signal with stop loss, take profit, position size.

```
/backtest EURUSD 15m 4
```
↑ Shows the model's *real* historical accuracy. Wait 30–60 seconds.

```
/stats
```
↑ After the bot runs for a few days, this shows your real paper-trading win rate.

```
/news EURUSD
```
↑ Checks for high-impact news in the next 30 minutes.

🎉 **You're done. You have a fully working forex signal bot.**

---

## 🆘 Troubleshooting

**❓ "Render says my service crashed"**
→ Click the **Logs** tab. Look for red `ERROR` lines.
→ Most common: you mistyped the TELEGRAM_BOT_TOKEN. Go to **Environment** tab, fix it, save, the bot restarts automatically.

**❓ "My bot doesn't reply"**
→ Check Render Logs. Should say `Bot starting (polling)…`.
→ Make sure you pressed **START** in Telegram first.
→ Free Render workers sleep after 15 min of inactivity. To keep it awake:
   - Sign up free at https://uptimerobot.com (only needed for a web service, not worker — worker stays alive on free tier as long as you visit the dashboard once every few weeks)
   - For 100% uptime, upgrade Render Background Worker to $7/month.

**❓ "/signal says 'no data'"**
→ Yahoo Finance sometimes blocks free cloud IPs. Add a free **TWELVEDATA_API_KEY** (Step 3.4 optional row) — get one at https://twelvedata.com/register.

**❓ "Screenshot doesn't work"**
→ Needs OPENAI_API_KEY (Step 3.4 optional). Costs roughly $0.0001 per screenshot.

**❓ "I want to add more pairs"**
→ Open GitHub → `bot/data_fetcher.py` → click the ✏️ pencil → add a line in `YAHOO_MAP`, e.g.:
```python
"USDMXN": "USDMXN=X",
```
→ Commit changes → Render auto-redeploys in 2 minutes.

---

## 🧠 How to actually use this without losing money

This is the most important section. **Read it twice.**

### Rules:
1. **Paper-trade for 30 days first.** Use the `/signal` command, write down each signal, watch what happens. Use `/stats` to see the real win rate. Do NOT use real money yet.
2. **Only take ✅ TAKE signals.** Skip ⚠️ WAIT and ⛔ SKIP. The bot only logs ✅ TAKEs for stats — trust that filter.
3. **Trade only during London-NY overlap** (12:00–16:00 UTC). The bot tells you this in `/sessions`.
4. **Never trade ±30 min around high-impact news.** The bot warns you, but double-check yourself.
5. **Risk only 1% per trade.** The bot's suggested lot size assumes a $1000 account at 1% risk. Adjust to your account.
6. **Use the stop loss. ALWAYS.** No "let me wait, it'll come back". That's how accounts die.
7. **If `/stats` shows win rate below 50% after 50 trades, the bot has no edge for you.** Either switch pairs/timeframes or stop. Don't keep losing real money hoping it'll turn around.

### Realistic expectations:
- Backtest accuracy: 52–58% ✅ realistic
- Backtest accuracy: 80%+ 🚨 overfit, won't repeat live
- Live win rate after 50 trades: probably 48–55%
- With 1:1.7 R:R and 52% win rate, you'd be slightly profitable. **That's actually good in forex.**

### Red flags in OTHER signal bots:
- "98% win rate" → lying
- "$10 → $10,000 in a week" → scam
- "Pay $97 for premium signals" → scam
- "Guaranteed profits" → scam
- "Trade these binary options in 60 seconds" → gambling, often rigged

This bot is free and shows you the math. That's the difference. ✊

---

## 🤝 Need help?

If you get stuck, copy the **last 30 lines of the Render Logs** and the **exact error message**, and ask me. I can debug from those.

Happy (responsible) trading! 🚀
