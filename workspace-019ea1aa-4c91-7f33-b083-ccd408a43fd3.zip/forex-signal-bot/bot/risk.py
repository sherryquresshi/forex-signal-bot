"""ATR-based stop loss / take profit and position sizing.

Rule:  Stop = entry ± 1.5 × ATR
       TP1  = entry ± 1.0 × ATR   (close half)
       TP2  = entry ± 2.5 × ATR   (close rest)
       Risk = 1% of account per trade
"""
from __future__ import annotations


def pip_size(pair: str) -> float:
    return 0.01 if "JPY" in pair.upper() else 0.0001


def build_trade_plan(pair: str, direction: str, entry: float, atr: float,
                     account_balance: float = 1000.0, risk_pct: float = 1.0) -> dict:
    psize = pip_size(pair)
    direction = direction.upper()
    sign = +1 if direction == "UP" else -1

    sl = entry - sign * 1.5 * atr
    tp1 = entry + sign * 1.0 * atr
    tp2 = entry + sign * 2.5 * atr

    sl_pips = abs(entry - sl) / psize
    tp1_pips = abs(tp1 - entry) / psize
    tp2_pips = abs(tp2 - entry) / psize
    rr = tp2_pips / sl_pips if sl_pips else 0

    # Position sizing: risk_amount = lots * sl_pips * pip_value
    # For standard lot, 1 pip ≈ $10 on USD-quote majors (rough)
    pip_value_per_lot = 10.0
    risk_amount = account_balance * (risk_pct / 100)
    lots = risk_amount / (sl_pips * pip_value_per_lot) if sl_pips else 0

    return {
        "direction": direction,
        "entry": entry,
        "sl": sl, "sl_pips": sl_pips,
        "tp1": tp1, "tp1_pips": tp1_pips,
        "tp2": tp2, "tp2_pips": tp2_pips,
        "rr": rr,
        "lots": round(lots, 2),
        "risk_amount": round(risk_amount, 2),
    }
