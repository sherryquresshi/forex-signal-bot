"""Tiny smoke tests — run without network using a synthetic OHLC dataframe."""
import numpy as np
import pandas as pd

from bot import indicators, ml_model


def _synthetic(n=1500, seed=0):
    rng = np.random.default_rng(seed)
    rets = rng.normal(0, 0.0008, n).cumsum()
    close = 1.10 * np.exp(rets)
    idx = pd.date_range("2024-01-01", periods=n, freq="15min")
    df = pd.DataFrame({
        "open": close, "high": close * 1.0005, "low": close * 0.9995,
        "close": close, "volume": 0.0,
    }, index=idx)
    return df


def test_indicators_run():
    df = _synthetic()
    out = indicators.add_all(df).dropna()
    assert {"rsi14", "macd_hist", "ema200", "atr14"} <= set(out.columns)
    bias = indicators.rule_based_bias(df)
    assert bias["bias"] in {"BULLISH", "BEARISH", "NEUTRAL"}


def test_ml_backtest():
    df = _synthetic()
    res, _ = ml_model.walk_forward_backtest(df, horizon=4, n_splits=3)
    assert res.samples > 0
    assert 0.0 <= res.accuracy <= 1.0
    print(f"acc={res.accuracy:.3f}  pf={res.profit_factor:.2f}")


if __name__ == "__main__":
    test_indicators_run()
    test_ml_backtest()
    print("✅ smoke tests passed")
