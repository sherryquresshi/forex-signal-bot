"""Technical indicators + rule-based bias.

Uses the `ta` library where possible, with a hand-rolled fallback so we
don't crash if a column is missing.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0).rolling(period).mean()
    loss = -delta.clip(upper=0).rolling(period).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def ema(s: pd.Series, period: int) -> pd.Series:
    return s.ewm(span=period, adjust=False).mean()


def macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    macd_line = ema(close, fast) - ema(close, slow)
    sig = ema(macd_line, signal)
    hist = macd_line - sig
    return macd_line, sig, hist


def bollinger(close: pd.Series, period: int = 20, mult: float = 2.0):
    mid = close.rolling(period).mean()
    std = close.rolling(period).std()
    upper = mid + mult * std
    lower = mid - mult * std
    return upper, mid, lower


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = df["high"], df["low"], df["close"]
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low).abs(),
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(period).mean()


def add_all(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["rsi14"] = rsi(out["close"], 14)
    macd_line, sig, hist = macd(out["close"])
    out["macd"] = macd_line
    out["macd_sig"] = sig
    out["macd_hist"] = hist
    up, mid, lo = bollinger(out["close"])
    out["bb_up"], out["bb_mid"], out["bb_lo"] = up, mid, lo
    out["bb_pos"] = (out["close"] - lo) / (up - lo).replace(0, np.nan)
    out["ema20"] = ema(out["close"], 20)
    out["ema50"] = ema(out["close"], 50)
    out["ema200"] = ema(out["close"], 200)
    out["atr14"] = atr(out, 14)
    out["ret_1"] = out["close"].pct_change(1)
    out["ret_3"] = out["close"].pct_change(3)
    out["ret_5"] = out["close"].pct_change(5)
    return out


def rule_based_bias(df: pd.DataFrame) -> dict:
    """Combine indicators into a transparent bullish/bearish vote."""
    d = add_all(df).dropna()
    if d.empty:
        return {"bias": "NEUTRAL", "score": 0, "votes": [], "price": None}

    last = d.iloc[-1]
    votes = []

    # Trend (EMA stack)
    if last["ema20"] > last["ema50"] > last["ema200"]:
        votes.append(("Trend (EMA stack)", +1, "Bullish stack 20>50>200"))
    elif last["ema20"] < last["ema50"] < last["ema200"]:
        votes.append(("Trend (EMA stack)", -1, "Bearish stack 20<50<200"))
    else:
        votes.append(("Trend (EMA stack)", 0, "Mixed / no clear trend"))

    # RSI
    if last["rsi14"] < 30:
        votes.append(("RSI(14)", +1, f"Oversold {last['rsi14']:.1f}"))
    elif last["rsi14"] > 70:
        votes.append(("RSI(14)", -1, f"Overbought {last['rsi14']:.1f}"))
    else:
        bias = +1 if last["rsi14"] > 50 else -1
        votes.append(("RSI(14)", bias * 0, f"Neutral {last['rsi14']:.1f}"))

    # MACD histogram
    if last["macd_hist"] > 0 and last["macd_hist"] > d["macd_hist"].iloc[-2]:
        votes.append(("MACD hist", +1, "Rising above 0"))
    elif last["macd_hist"] < 0 and last["macd_hist"] < d["macd_hist"].iloc[-2]:
        votes.append(("MACD hist", -1, "Falling below 0"))
    else:
        votes.append(("MACD hist", 0, "No clear momentum"))

    # Bollinger position
    if last["bb_pos"] < 0.1:
        votes.append(("Bollinger", +1, "Near lower band (mean-reversion long)"))
    elif last["bb_pos"] > 0.9:
        votes.append(("Bollinger", -1, "Near upper band (mean-reversion short)"))
    else:
        votes.append(("Bollinger", 0, f"Mid-band ({last['bb_pos']:.2f})"))

    score = sum(v[1] for v in votes)
    if score >= 2:
        bias = "BULLISH"
    elif score <= -2:
        bias = "BEARISH"
    else:
        bias = "NEUTRAL"

    return {
        "bias": bias,
        "score": score,
        "votes": votes,
        "price": float(last["close"]),
        "rsi": float(last["rsi14"]),
        "atr": float(last["atr14"]),
    }
