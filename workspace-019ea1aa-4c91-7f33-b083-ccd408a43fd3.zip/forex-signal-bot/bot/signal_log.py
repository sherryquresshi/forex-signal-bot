"""Paper-trading signal log: every prediction the bot publishes is recorded
and later auto-graded so users see *real* live performance, not just backtest.

Stored as a simple SQLite DB so it survives restarts.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "signals.db"
DB_PATH.parent.mkdir(exist_ok=True)


def _conn():
    c = sqlite3.connect(DB_PATH)
    c.execute("""
        CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT, pair TEXT, interval TEXT, horizon INT,
            direction TEXT, confidence REAL, entry REAL,
            sl REAL, tp1 REAL, tp2 REAL, atr REAL,
            status TEXT DEFAULT 'OPEN',
            exit_price REAL, exit_ts TEXT, result TEXT, pips REAL
        )
    """)
    return c


def log_signal(pair: str, interval: str, horizon: int, direction: str,
               confidence: float, entry: float, sl: float, tp1: float,
               tp2: float, atr: float) -> int:
    with _conn() as c:
        cur = c.execute("""
            INSERT INTO signals (ts, pair, interval, horizon, direction,
                                 confidence, entry, sl, tp1, tp2, atr)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (datetime.now(timezone.utc).isoformat(), pair, interval, horizon,
              direction, confidence, entry, sl, tp1, tp2, atr))
        return cur.lastrowid


def get_open_signals() -> list[dict]:
    with _conn() as c:
        c.row_factory = sqlite3.Row
        rows = c.execute("SELECT * FROM signals WHERE status='OPEN'").fetchall()
        return [dict(r) for r in rows]


def close_signal(sid: int, exit_price: float, result: str, pips: float):
    with _conn() as c:
        c.execute("""
            UPDATE signals SET status='CLOSED', exit_price=?, exit_ts=?,
                               result=?, pips=? WHERE id=?
        """, (exit_price, datetime.now(timezone.utc).isoformat(),
              result, pips, sid))


def stats(pair: str | None = None) -> dict:
    with _conn() as c:
        q = "SELECT result, pips FROM signals WHERE status='CLOSED'"
        args = ()
        if pair:
            q += " AND pair=?"
            args = (pair,)
        rows = c.execute(q, args).fetchall()
    if not rows:
        return {"total": 0, "wins": 0, "losses": 0, "win_rate": 0.0,
                "total_pips": 0.0, "avg_pips": 0.0}
    wins = sum(1 for r, _ in rows if r == "WIN")
    losses = sum(1 for r, _ in rows if r == "LOSS")
    pips = sum(p or 0 for _, p in rows)
    return {
        "total": len(rows), "wins": wins, "losses": losses,
        "win_rate": wins / len(rows) * 100,
        "total_pips": pips,
        "avg_pips": pips / len(rows),
    }
