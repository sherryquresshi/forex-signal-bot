"""Telegram bot entry point — upgraded with multi-TF, news filter, sessions,
risk planner, paper-trade log, and auto-grading."""
from __future__ import annotations

import asyncio
import io
import logging
import os

from dotenv import load_dotenv
from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    Application, CommandHandler, ContextTypes,
    MessageHandler, filters,
)

from . import (
    data_fetcher, indicators, ml_model, screenshot, formatter,
    multi_tf, sessions, news_filter, risk, signal_log, grader,
)

load_dotenv()
logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("bot")

VALID_INTERVALS = {"1m", "5m", "15m", "30m", "1h", "4h", "1d"}

WELCOME = """👋 *Forex Signal Bot* — free, honest, top-tier

*Main commands:*
• `/signal EURUSD 15m` — high-conviction signal w/ SL/TP & risk plan
• `/analyze EURUSD 15m` — live indicator analysis
• `/backtest EURUSD 15m 4` — honest historical performance
• `/stats` or `/stats EURUSD` — real paper-trade win rate
• `/sessions` — which markets are open right now
• `/news EURUSD` — high-impact news check
• `/pairs` — list supported pairs
• Send a *screenshot* → I'll identify it and run a full signal

*Why this bot is different:*
✓ Multi-timeframe agreement (15m + 1h must agree)
✓ Trading-session filter (avoids dead hours)
✓ High-impact news avoidance (±30m)
✓ ATR-based stop/take-profit + 1% risk sizing
✓ Auto-graded paper-trade log → real win rate over time
✓ Walk-forward backtest → no fake numbers

*Honest disclaimer:* Short-term moves are mostly random. Realistic accuracy is 52–58%.
Educational only. *Never trade money you can't afford to lose.*
"""


def _parse_args(args, defaults=("EURUSD", "15m", 4)):
    pair = data_fetcher.normalize_pair(args[0]) if len(args) >= 1 else defaults[0]
    interval = args[1].lower() if len(args) >= 2 else defaults[1]
    horizon = int(args[2]) if len(args) >= 3 else defaults[2]
    return pair, interval, horizon


# ----------------- handlers -----------------

async def cmd_start(update: Update, _):
    await update.message.reply_text(WELCOME, parse_mode=ParseMode.MARKDOWN)


async def cmd_pairs(update: Update, _):
    pairs = ", ".join(f"`{p}`" for p in data_fetcher.supported_pairs())
    await update.message.reply_text(
        f"*Supported pairs:*\n{pairs}\n\n*Timeframes:* {', '.join(sorted(VALID_INTERVALS))}",
        parse_mode=ParseMode.MARKDOWN,
    )


async def cmd_sessions(update: Update, _):
    active = sessions.current_sessions()
    overlap = sessions.is_overlap()
    msg = f"*Active sessions:* {', '.join(active) if active else 'NONE'}\n"
    msg += f"*London-NY overlap:* {'✅ YES' if overlap else '❌ NO'}\n\n"
    msg += "_Best trading window = overlap (12:00–16:00 UTC)._"
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)


async def cmd_news(update, context):
    pair = data_fetcher.normalize_pair(context.args[0]) if context.args else "EURUSD"
    n = news_filter.check_news(pair)
    await update.message.reply_text(f"*{pair}* — {n['msg']}", parse_mode=ParseMode.MARKDOWN)


async def cmd_analyze(update, context):
    try:
        pair, interval, _ = _parse_args(context.args)
    except Exception:
        await update.message.reply_text("Usage: `/analyze EURUSD 15m`", parse_mode=ParseMode.MARKDOWN)
        return
    if interval not in VALID_INTERVALS:
        await update.message.reply_text(f"Bad timeframe. Use: {', '.join(VALID_INTERVALS)}")
        return
    df = data_fetcher.get_ohlc(pair, interval)
    if df is None or df.empty:
        await update.message.reply_text(f"❌ Couldn't fetch {pair} {interval}.")
        return
    bias = indicators.rule_based_bias(df)
    await update.message.reply_text(
        formatter.format_analysis(pair, interval, bias),
        parse_mode=ParseMode.MARKDOWN,
    )


async def cmd_signal(update, context):
    """The flagship command — full high-conviction signal."""
    try:
        pair, interval, horizon = _parse_args(context.args)
    except Exception:
        await update.message.reply_text("Usage: `/signal EURUSD 15m [horizon]`", parse_mode=ParseMode.MARKDOWN)
        return
    if interval not in VALID_INTERVALS:
        await update.message.reply_text(f"Bad timeframe. Use: {', '.join(VALID_INTERVALS)}")
        return
    horizon = max(1, min(horizon, 50))
    await update.message.reply_text("⏳ Building signal (multi-TF + news + risk plan)…")

    sig = multi_tf.multi_tf_signal(pair, interval, horizon)
    if "error" in sig:
        await update.message.reply_text(f"❌ {sig['error']}")
        return

    # Session + news filters
    sess = sessions.session_quality(pair)
    news = news_filter.check_news(pair)

    # Risk plan
    df = data_fetcher.get_ohlc(pair, interval)
    bias = indicators.rule_based_bias(df)
    plan = risk.build_trade_plan(
        pair, sig["ml"]["direction"], bias["price"], bias["atr"],
    )

    # Override recommendation if news or session bad
    if not news["safe"]:
        sig["recommendation"] = "⛔ SKIP — high-impact news window"
    elif sess[0] == "POOR":
        sig["recommendation"] = "⚠️ WAIT — low-liquidity hours"

    msg = formatter.format_signal(sig, plan, sess, news)
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)

    # Log signal only if it's a TAKE recommendation
    if sig["recommendation"].startswith("✅"):
        sid = signal_log.log_signal(
            pair, interval, horizon, sig["ml"]["direction"],
            sig["conviction"] / 100, plan["entry"], plan["sl"],
            plan["tp1"], plan["tp2"], bias["atr"],
        )
        await update.message.reply_text(f"📝 Logged as signal #{sid} for paper-tracking.")


async def cmd_backtest(update, context):
    try:
        pair, interval, horizon = _parse_args(context.args)
    except Exception:
        await update.message.reply_text("Usage: `/backtest EURUSD 15m 4`", parse_mode=ParseMode.MARKDOWN)
        return
    if interval not in VALID_INTERVALS:
        await update.message.reply_text(f"Bad timeframe. Use: {', '.join(VALID_INTERVALS)}")
        return
    horizon = max(1, min(horizon, 50))
    await update.message.reply_text("⏳ Running walk-forward backtest (20–60s)…")
    df = data_fetcher.get_ohlc(pair, interval)
    if df is None or len(df) < 600:
        await update.message.reply_text(f"❌ Not enough data for {pair} {interval}.")
        return
    res = ml_model.train_and_save(df, pair, interval, horizon)
    await update.message.reply_text(
        formatter.format_backtest(pair, interval, horizon, res.__dict__),
        parse_mode=ParseMode.MARKDOWN,
    )


async def cmd_stats(update, context):
    pair = data_fetcher.normalize_pair(context.args[0]) if context.args else None
    s = signal_log.stats(pair)
    await update.message.reply_text(
        formatter.format_stats(s, pair), parse_mode=ParseMode.MARKDOWN,
    )


async def on_photo(update, context):
    if not os.getenv("OPENAI_API_KEY"):
        await update.message.reply_text(
            "📷 Screenshot needs OPENAI_API_KEY. Use `/signal EURUSD 15m` instead.",
            parse_mode=ParseMode.MARKDOWN,
        )
        return
    await update.message.reply_text("🔍 Reading screenshot…")
    photo = update.message.photo[-1]
    f = await photo.get_file()
    buf = io.BytesIO()
    await f.download_to_memory(out=buf)
    info = screenshot.identify_chart(buf.getvalue())
    if not info or info.get("pair") in (None, "UNKNOWN"):
        await update.message.reply_text("❌ Couldn't identify. Try `/signal EURUSD 15m`.")
        return
    pair = data_fetcher.normalize_pair(info["pair"])
    interval = info.get("timeframe", "15m")
    if interval not in VALID_INTERVALS:
        interval = "15m"
    await update.message.reply_text(
        f"✅ Identified: *{pair}* on *{interval}* (conf {info.get('confidence', 0):.0%})",
        parse_mode=ParseMode.MARKDOWN,
    )
    # Run full signal
    context.args = [pair, interval]
    await cmd_signal(update, context)


async def on_error(update, context):
    log.exception("handler error", exc_info=context.error)


# ----------------- startup -----------------

async def _post_init(app):
    asyncio.create_task(grader.grade_loop(300))
    log.info("Background grader started.")


def main():
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        raise SystemExit("❌ TELEGRAM_BOT_TOKEN missing. Copy .env.example → .env and fill it.")

    app = Application.builder().token(token).post_init(_post_init).build()
    app.add_handler(CommandHandler(["start", "help"], cmd_start))
    app.add_handler(CommandHandler("pairs", cmd_pairs))
    app.add_handler(CommandHandler("sessions", cmd_sessions))
    app.add_handler(CommandHandler("news", cmd_news))
    app.add_handler(CommandHandler("analyze", cmd_analyze))
    app.add_handler(CommandHandler("signal", cmd_signal))
    app.add_handler(CommandHandler("backtest", cmd_backtest))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(MessageHandler(filters.PHOTO, on_photo))
    app.add_error_handler(on_error)

    log.info("Bot starting (polling)…")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
