"""Trading session filter.

The forex market moves in waves driven by which financial centers are open.
Best volatility/liquidity is during the London + New York overlap (12:00-16:00 UTC).
We avoid the dead Asian-only hours unless trading JPY/AUD pairs.
"""
from __future__ import annotations

from datetime import datetime, timezone


# Hours are in UTC
SESSIONS = {
    "Sydney":   (22, 7),
    "Tokyo":    (0, 9),
    "London":   (7, 16),
    "New York": (12, 21),
}

# The golden window: London + NY both open
OVERLAP_START_UTC = 12
OVERLAP_END_UTC = 16


def current_sessions(now: datetime | None = None) -> list[str]:
    now = now or datetime.now(timezone.utc)
    h = now.hour
    active = []
    for name, (start, end) in SESSIONS.items():
        if start < end:
            if start <= h < end:
                active.append(name)
        else:  # wraps midnight (Sydney)
            if h >= start or h < end:
                active.append(name)
    return active


def is_overlap(now: datetime | None = None) -> bool:
    now = now or datetime.now(timezone.utc)
    return OVERLAP_START_UTC <= now.hour < OVERLAP_END_UTC


def session_quality(pair: str, now: datetime | None = None) -> tuple[str, str]:
    """Return ('GOOD'|'OK'|'POOR', explanation)."""
    now = now or datetime.now(timezone.utc)
    active = current_sessions(now)
    pair = pair.upper()

    if is_overlap(now):
        return "GOOD", f"London+NY overlap (active: {', '.join(active)})"

    if "JPY" in pair and "Tokyo" in active:
        return "GOOD", "Tokyo session — ideal for JPY pairs"
    if "AUD" in pair and ("Sydney" in active or "Tokyo" in active):
        return "OK", "Sydney/Tokyo — decent for AUD pairs"
    if "London" in active or "New York" in active:
        return "OK", f"Active: {', '.join(active)}"
    if not active:
        return "POOR", "All major sessions closed — avoid trading"
    return "POOR", f"Low-volume hours (only {', '.join(active)} open)"
